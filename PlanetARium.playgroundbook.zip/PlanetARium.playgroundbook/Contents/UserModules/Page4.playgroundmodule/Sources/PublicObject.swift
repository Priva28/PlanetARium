import SwiftUI
import SharedCode

public class PublicObject: ObservableObject {
    
    public init() {}
    @Published var predictedMask: CGImage?
    @Published var numberOfFingers: Int = 0
    @Published var topPoint = IntPoint(x: 0, y: 0)
    @Published var finger0Size = IntSize(width: 0, height: 0)
}
