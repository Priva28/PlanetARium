import SwiftUI
import RealityKit
import ARKit
import Vision
import SharedCode

struct ARViewContainer: UIViewRepresentable {
    
    @EnvironmentObject var publicObject: PublicObject
    
    var arView = ARView(frame: .init(x: 1, y: 1, width: 1, height: 1), cameraMode: .ar, automaticallyConfigureSession: false)
    
    func makeUIView(context: Context) -> ARView {
        arView.session.delegate = context.coordinator
        let config = ARWorldTrackingConfiguration()
        arView.session.run(config)
        return arView
    }
    
    func updateUIView(_ uiView: ARView, context: Context) { }
    
    func resetAR() {
        arView.session.run(ARWorldTrackingConfiguration(), options: [.resetTracking])
    }
    
    func stopAR() {
        arView.session.pause()
    }
    
    func makeCoordinator() -> ARViewContainer.Coordinator {
        Coordinator(self)
    }
    
    class Coordinator: NSObject, ARSessionDelegate {
        
        var parent: ARViewContainer
        
        private var currentBuffer: CVPixelBuffer?
        private let visionQueue = DispatchQueue(label: "com.priva28.fingertipdetection.vision")
        private let ciContext = CIContext()
        
        private lazy var visionRequest: VNCoreMLRequest = {
            do {
                let model = try VNCoreMLModel(for: FingertipModel().model)
                let request = VNCoreMLRequest(model: model)
                
                request.imageCropAndScaleOption = .centerCrop
                
                return request
            } catch {
                fatalError("Couldnt find the requested CoreML model.")
            }
        }()
        
        func session(_ session: ARSession, didUpdate frame: ARFrame) {
            
            // This is where we process the frame from the AR view. This function is called 30 times per second and lets us grab the current frame.
            
            
            // This is going to make sure that we are not currently processing an image. We do this by making sure that the pixel buffer (grabbed frame) is not filled as we empty it when we are done processing.
            guard currentBuffer == nil else { return }
            
            // If we pass the checks above, lets set the current buffer to the new, updated pixel buffer (grabbed frame)
            currentBuffer = frame.capturedImage
            //print("making")
            makeMask()
        }
        
        private func makeMask() {
            
            guard let buffer = currentBuffer else { return }
            
            let requestHandler = VNImageRequestHandler(cvPixelBuffer: buffer, orientation: .right)
            //print("here")
            visionQueue.async {
                do {
                    //print("here1")
                    defer {
                        self.currentBuffer = nil
                    }
                    
                    try requestHandler.perform([self.visionRequest])
                    
                    guard let mask = self.visionRequest.results?.first as? VNPixelBufferObservation else {
                        fatalError("Unexpected result type from the vision request.")
                    }
                    
                    let result = mask.pixelBuffer
                    let fingers = result.countWhiteDots()
                    let topPoint = findHighestPoint(fingers: fingers)
                    var finger0Size = IntSize(width: 0, height: 0)
                    if fingers.count > 0 {
                        finger0Size = fingers[0].size
                    }
                    
                    DispatchQueue.main.async {
                        
                        let ciImage = CIImage(cvImageBuffer: result)
                        let cgImage = self.ciContext.createCGImage(ciImage, from: ciImage.extent)
                        
                        self.parent.publicObject.predictedMask = cgImage
                        self.parent.publicObject.numberOfFingers = fingers.count
                        self.parent.publicObject.topPoint = topPoint
                        self.parent.publicObject.finger0Size = finger0Size
                    }
                    
                    
                } catch {
                    print("fail")
                }
            }
            
        }
        
        init(_ parent: ARViewContainer) {
            self.parent = parent
        }
    }
}
