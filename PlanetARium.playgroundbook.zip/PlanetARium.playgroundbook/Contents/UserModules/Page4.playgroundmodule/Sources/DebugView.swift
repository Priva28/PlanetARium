import SwiftUI

public struct DebugView: View {
    @EnvironmentObject var publicObject: PublicObject
    let arView = ARViewContainer()
    let context = CIContext()
    
    public init() {}
    
    public var body: some View {
        ZStack {
            arView
            if self.publicObject.predictedMask != nil {
                VStack {
                    HStack {
                        Image(uiImage: UIImage(cgImage: self.publicObject.predictedMask!))
                        Spacer()
                    }
                    Spacer()
                    Text("Number of fingers: \(self.publicObject.numberOfFingers)")
                    Text("Topmost finger position: (x: \(self.publicObject.topPoint.x), y: \(self.publicObject.topPoint.y))")
                    Text("Finger 1 size: \(self.publicObject.finger0Size.width * self.publicObject.finger0Size.height)")
                    Spacer()
                }
            }
        }
        .edgesIgnoringSafeArea(.all)
        .onAppear {
            self.arView.resetAR()
        }
        .onDisappear {
            self.arView.stopAR()
        }
    }
}
