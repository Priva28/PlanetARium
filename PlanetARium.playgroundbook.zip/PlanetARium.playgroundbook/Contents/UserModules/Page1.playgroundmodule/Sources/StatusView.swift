
import SwiftUI
import SharedCode

struct StatusView: View {
    
    @EnvironmentObject var arController: ARController1
    @State var animation = false
    
    var body: some View {
        VStack {
            HStack {
                Circle()
                    .frame(width: 50, height: 50)
                    .cornerRadius(100)
                    .foregroundColor(Color(red: 0/255, green: 138/255, blue: 253/255))
                    .shadow(radius: 10)
                    .overlay(
                        Image(systemName: arController.gesturesEnabled ? "hand.raised.slash.fill" : "hand.raised.fill")
                            .foregroundColor(.white)
                )
                    .onTapGesture {
                        if self.arController.gesturesEnabled {
                            self.arController.gesturesEnabled = false
                        } else {
                            self.arController.gesturesEnabled = true
                        }
                }
                if self.arController.addedMonitor && self.arController.text1 && self.arController.text2 && self.arController.madeScreenBig && self.arController.showed5Fingers && self.arController.hasSwiped && !self.arController.gesturesEnabled {
                    Circle()
                        .frame(width: 50, height: 50)
                        .cornerRadius(100)
                        .foregroundColor(Color(red: 0/255, green: 138/255, blue: 253/255))
                        .shadow(radius: 10)
                        .overlay(
                            Image(systemName: "info.circle.fill")
                                .foregroundColor(.white)
                    )
                        .onTapGesture {
                            if self.arController.currentPlanet == -1 {
                                self.arController.updatePlanet()
                            } else {
                                self.arController.currentPlanet = -1
                                self.arController.removePlanet()
                            }
                            if !self.arController.showed3Fingers {
                                self.arController.showed3Fingers = true
                                self.arController.instruction = "Good job!"
                                
                                DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                                    self.arController.instruction = "Tap to continue."
                                }
                            }
                    }
                }
            }
            Spacer()
            HStack {
                if !arController.gesturesEnabled && arController.showed5Fingers {
                    Circle()
                        .frame(width: 50, height: 50)
                        .cornerRadius(100)
                        .foregroundColor(Color(red: 0/255, green: 138/255, blue: 253/255))
                        .shadow(radius: 10)
                        .overlay(
                            Image(systemName: "chevron.left")
                                .foregroundColor(.white)
                    )
                        .onTapGesture {
                            self.arController.planetPage = max(self.arController.planetPage - 1, 0)
                            if self.arController.currentPlanet != -1 {
                                self.arController.updatePlanet()
                            }
                            if !self.arController.hasSwiped {
                                self.arController.hasSwiped = true
                                self.arController.instruction = "Good job!"
                                
                                DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                                    self.arController.instruction = "Tap to continue."
                                }
                            }
                    }.padding()
                    Spacer()
                    Circle()
                        .frame(width: 50, height: 50)
                        .cornerRadius(100)
                        .foregroundColor(Color(red: 0/255, green: 138/255, blue: 253/255))
                        .shadow(radius: 10)
                        .overlay(
                            Image(systemName: "chevron.right")
                                .foregroundColor(.white)
                    )
                        .onTapGesture {
                            self.arController.planetPage = min(self.arController.planetPage + 1, 7)
                            if self.arController.currentPlanet != -1 {
                                self.arController.updatePlanet()
                            }
                            if !self.arController.hasSwiped {
                                self.arController.hasSwiped = true
                                self.arController.instruction = "Good job!"
                                
                                DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                                    self.arController.instruction = "Tap to continue."
                                }
                            }
                    }.padding()
                }
            }
            Spacer()
            ZStack {
                VStack {
                    if arController.showHandGesture1Vid || arController.showHandGesture2Vid || arController.showHandGesture3Vid {
                        LoopingVid(fileName: arController.showHandGesture1Vid ? "handgesture1" : arController.showHandGesture2Vid ? "handgesture2" : "handgesture3")
                            .padding()
                            .frame(width: 355.6, height: 200)
                            .transition(.scale)
                            .animation(.default)
                    }
                    HStack {
                        Image(systemName: "arkit")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 30)
                            .padding(.leading)
                            .foregroundColor(.white)
                            .scaleEffect(animation ? 1 : 0.8)
                            .onAppear {
                                withAnimation(Animation.easeInOut(duration: 1.5).repeatForever(autoreverses: true)) {
                                    self.animation.toggle()
                                }
                        }
                        Text("\(arController.instruction)")
                            .foregroundColor(.white)
                            .padding(.trailing)
                    }
                }
                .padding()
                .background(
                    Rectangle()
                        .cornerRadius(50)
                        .foregroundColor(Color(red: 0/255, green: 138/255, blue: 253/255))
                        .shadow(radius: 10)
                )
                    .animation(.default)
            }
        }
    }
}
