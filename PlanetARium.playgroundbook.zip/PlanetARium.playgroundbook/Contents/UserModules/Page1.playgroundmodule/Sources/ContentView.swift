import SwiftUI

public struct ContentView: View {
    
    @State var titleShown = false
    @State var tapToStartShown = false
    @State var tapToStartAnimation = false
    @State var begun = false
    
    public init() {}
    
    public var body: some View {
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
            self.titleShown = true
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            self.tapToStartShown = true
        }
        
        return ZStack {
            Rectangle()
                .foregroundColor(.black)
                .edgesIgnoringSafeArea(.all)
            VStack {
                Spacer()
                if titleShown {
                    Text("PlanetARium")
                        .font(.largeTitle).bold()
                        .transition(AnyTransition.opacity.animation(.default))
                        .animation(.default)
                }
                Spacer()
                if tapToStartShown {
                    Text("Tap anywhere to begin.")
                        .transition(AnyTransition.opacity.animation(.default))
                        .opacity(tapToStartAnimation ? 1 : 0.2)
                        .onAppear {
                            withAnimation(Animation.easeInOut(duration: 1).repeatForever(autoreverses: true)) {
                                self.tapToStartAnimation.toggle()
                            }
                    }
                }
                Spacer()
            }
            if begun {
                ARShowView()
                    .transition(AnyTransition.scale.animation(.easeIn))
                    .edgesIgnoringSafeArea(.all)
                StatusView()
            }
        }.onTapGesture {
            self.begun = true
        }
    }
}
