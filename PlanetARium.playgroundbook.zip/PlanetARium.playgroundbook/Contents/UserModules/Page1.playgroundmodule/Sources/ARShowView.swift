
import SwiftUI
import ARKit
import SharedCode

struct ARShowView: View {
    
    @State var tap = false
    @EnvironmentObject var arController: ARController1
    
    var body: some View {
        ARContainerView(arView: ARController1.shared.arView)
            .gesture(
                DragGesture(minimumDistance: 0, coordinateSpace: .global)
                    .onChanged { value in
                        if !self.tap {
                            self.tap = true
                            self.arController.handleTap(position: value.location)
                        }
                }
                .onEnded { _ in
                    self.tap = false
                }
        )
            .simultaneousGesture(LongPressGesture(minimumDuration: 0.8)
                .onEnded { _ in
                    if !self.arController.gesturesEnabled && self.arController.addedMonitor && self.arController.text1 && self.arController.text2 && self.arController.madeScreenBig {
                        let screen = self.arController.arView.scene.rootNode.childNode(withName: "screen", recursively: true)
                        SCNTransaction.animationDuration = 0.3
                        let position = SCNVector3(x: 0, y: 0, z: -1.5)
                        self.arController.updatePositionAndOrientationOf(screen!, withPosition: position, relativeTo: self.arController.arView.pointOfView!)
                        self.arController.showed5Fingers = true
                        if !self.arController.showed5Fingers {
                            self.arController.showed5Fingers = true
                            self.arController.instruction = "Good job!"
                            
                            DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                                self.arController.instruction = "Tap to continue."
                            }
                        }
                    }
                }
        )
    }
}
