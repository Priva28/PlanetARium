
import SwiftUI

struct ARScreen: View {
    
    @EnvironmentObject var arController: ARController1
    @State var mainText = "Move me!"
    var earthAttributes = [
        PlanetAttribute(attribute: "Radius", value: "6,371 km"),
        PlanetAttribute(attribute: "Mass", value: "5.91 septillion kg"),
        PlanetAttribute(attribute: "Moons", value: "1"),
        PlanetAttribute(attribute: "Population", value: "7.594 billion"),
        PlanetAttribute(attribute: "Planet from the sun", value: "3rd"),
        PlanetAttribute(attribute: "Length of year", value: "365 days")
    ]
    
    var mercuryAttributes = [
        PlanetAttribute(attribute: "Radius", value: "2,439.7 km"),
        PlanetAttribute(attribute: "Mass", value: "330.14 sextillion kg"),
        PlanetAttribute(attribute: "Moons", value: "0"),
        PlanetAttribute(attribute: "Population", value: "0"),
        PlanetAttribute(attribute: "Planet from the sun", value: "1st"),
        PlanetAttribute(attribute: "Length of year", value: "88 days")
    ]
    
    var venusAttributes = [
        PlanetAttribute(attribute: "Radius", value: "6,051.8 km"),
        PlanetAttribute(attribute: "Mass", value: "4.81 septillion km"),
        PlanetAttribute(attribute: "Moons", value: "0"),
        PlanetAttribute(attribute: "Population", value: "0"),
        PlanetAttribute(attribute: "Planet from the sun", value: "2nd"),
        PlanetAttribute(attribute: "Length of year", value: "225 days")
    ]
    
    var marsAttributes = [
        PlanetAttribute(attribute: "Radius", value: "3,389.5 km"),
        PlanetAttribute(attribute: "Mass", value: "641.61 sextillion kg"),
        PlanetAttribute(attribute: "Moons", value: "2"),
        PlanetAttribute(attribute: "Population", value: "0"),
        PlanetAttribute(attribute: "Planet from the sun", value: "4th"),
        PlanetAttribute(attribute: "Length of year", value: "687 days")
    ]
    
    var jupiterAttributes = [
        PlanetAttribute(attribute: "Radius", value: "69,911 km"),
        PlanetAttribute(attribute: "Mass", value: "1.81 octillion kg"),
        PlanetAttribute(attribute: "Moons", value: "75+"),
        PlanetAttribute(attribute: "Population", value: "0"),
        PlanetAttribute(attribute: "Planet from the sun", value: "5th"),
        PlanetAttribute(attribute: "Length of year", value: "4333 days")
    ]
    
    var uranusAttributes = [
        PlanetAttribute(attribute: "Radius", value: "25,362 km"),
        PlanetAttribute(attribute: "Mass", value: "86.81 septillion kg"),
        PlanetAttribute(attribute: "Moons", value: "27+"),
        PlanetAttribute(attribute: "Population", value: "0"),
        PlanetAttribute(attribute: "Planet from the sun", value: "7th"),
        PlanetAttribute(attribute: "Length of year", value: "30,687 days")
    ]
    
    var neptuneAttributes = [
        PlanetAttribute(attribute: "Radius", value: "24,622 km"),
        PlanetAttribute(attribute: "Mass", value: "102.4 septillion kg"),
        PlanetAttribute(attribute: "Moons", value: "14"),
        PlanetAttribute(attribute: "Population", value: "0"),
        PlanetAttribute(attribute: "Planet from the sun", value: "8th"),
        PlanetAttribute(attribute: "Length of year", value: "60,190 days")
    ]
    
    var saturnAttributes = [
        PlanetAttribute(attribute: "Radius", value: "58,232 km"),
        PlanetAttribute(attribute: "Mass", value: "568.3 septillion kg"),
        PlanetAttribute(attribute: "Moons", value: "~82"),
        PlanetAttribute(attribute: "Population", value: "0"),
        PlanetAttribute(attribute: "Planet from the sun", value: "6th"),
        PlanetAttribute(attribute: "Length of year", value: "10,759 days")
    ]
    
    var body: some View {
        ZStack {
            Rectangle().foregroundColor(.white).opacity(0.7)
            HStack {
                InfoScreenLeft().frame(width: 130)
                Spacer()
                GeometryReader { geometry in
                    HStack(spacing: 0) {
                        PlanetInfo(planetName: "Earth", planetImage: "earth", planetAttributes: self.earthAttributes)
                            .frame(width: geometry.size.width)
                        PlanetInfo(planetName: "Mercury", planetImage: "mercury", planetAttributes: self.mercuryAttributes)
                            .frame(width: geometry.size.width)
                        PlanetInfo(planetName: "Venus", planetImage: "venus", planetAttributes: self.venusAttributes)
                            .frame(width: geometry.size.width)
                        PlanetInfo(planetName: "Mars", planetImage: "mars", planetAttributes: self.marsAttributes)
                            .frame(width: geometry.size.width)
                        PlanetInfo(planetName: "Jupiter", planetImage: "jupiter", planetAttributes: self.jupiterAttributes)
                            .frame(width: geometry.size.width)
                        PlanetInfo(planetName: "Uranus", planetImage: "uranus", planetAttributes: self.uranusAttributes)
                            .frame(width: geometry.size.width)
                        PlanetInfo(planetName: "Neptune", planetImage: "neptune", planetAttributes: self.neptuneAttributes)
                            .frame(width: geometry.size.width)
                        PlanetInfo(planetName: "Saturn", planetImage: "saturn", planetAttributes: self.saturnAttributes)
                            .frame(width: geometry.size.width)
                    }
                    .frame(width: geometry.size.width, alignment: .leading)
                    .offset(x: -CGFloat(self.arController.planetPage) * geometry.size.width)
                    .offset(x: CGFloat(self.arController.planetPageOffset))
                    .animation(.interactiveSpring())
                }
            }
        }
    }
}

struct PlanetAttribute: Hashable {
    var attribute: String
    var value: String
}

struct PlanetInfo: View {
    var planetName: String
    var planetImage: String
    var planetAttributes: [PlanetAttribute]
    var body: some View {
        HStack {
            Image(uiImage: UIImage(named: planetImage)!)
                .resizable()
                .scaledToFit()
                .frame(width: 360, height: 360)
                .padding()
            VStack {
                Text(planetName).font(.largeTitle).bold()
                Divider()
                VStack(alignment: .leading) {
                    ForEach(self.planetAttributes, id: \.self) { planetAttribute in
                        HStack {
                            Text("\(planetAttribute.attribute): ").bold()
                            Text("\(planetAttribute.value)")
                        }
                    }
                }
            }
        }
    }
}

struct InfoScreenLeft: View {
    
    @EnvironmentObject var arController: ARController1
    
    var body: some View {
        ZStack(alignment: .leading) {
            Rectangle()
                .foregroundColor(Color.gray.opacity(0.8))
            VStack(alignment: .leading, spacing: 10) {
                Group {
                    Text("Menu").font(.system(size: 22)).bold()
                    Divider()
                    Text("PlanetARium").font(.system(size: 17)).bold()
                    Divider()
                }
                Text("Gestures enabled: \(arController.gesturesEnabled ? "✅" : "❌")")
                Divider()
                Text("Hello,")
                Text("how are you")
                Text("today?")
                Divider()
                Spacer()
            }.padding()
        }
    }
}
