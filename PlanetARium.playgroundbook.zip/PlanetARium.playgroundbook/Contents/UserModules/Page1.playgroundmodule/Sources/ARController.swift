
import SwiftUI
import Vision
import ARKit
import PlaygroundSupport
import SharedCode

public final class ARController1: NSObject, ObservableObject, ARSCNViewDelegate, ARSessionDelegate {
    public static var shared = ARController1()
    
    var arView = ARSCNView(frame: .init(x: 1, y: 1, width: 1, height: 1))
    
    @Published var showHandGesture1Vid = false
    @Published var showHandGesture2Vid = false
    @Published var showHandGesture3Vid = false
    @Published var instruction = "Please find a table or floor, and tap on the surface through your screen to begin."
    
    public override init() {
        
        super.init()
        
        let config = ARWorldTrackingConfiguration()
        config.planeDetection = .horizontal
        arView.delegate = self
        arView.session.delegate = self
        arView.autoenablesDefaultLighting = true
        arView.automaticallyUpdatesLighting = true
        arView.session.run(config)
        arView.debugOptions = [.showFeaturePoints]
    }
    
    func featurePoints(show: Bool) {
        if show {
            arView.debugOptions = [.showFeaturePoints]
        } else {
            arView.debugOptions = []
        }
    }
    
    func addScreen(onMonitor: Bool = true) {
        
        let monitor = arView.scene.rootNode.childNode(withName: "monitor", recursively: true)
        
        let plane = SCNPlane(width: onMonitor ? 0.37 : 1, height: onMonitor ? 0.21 : 0.56)
        let screenNode = SCNNode(geometry: plane)
        
        screenNode.name = "screen"
        
        DispatchQueue.main.async {
            
            let materialView = UIHostingController(rootView: ARScreen().environmentObject(ARController1.shared)).view!
            materialView.isOpaque = false
            materialView.backgroundColor = UIColor.clear
            materialView.frame = CGRect(x: 0, y: 0, width: 1000, height: 560)
            
            let material = SCNMaterial()
            material.diffuse.contents = materialView
            screenNode.geometry?.materials = [material]
        }
        
        let animation = SCNAction.scale(to: 1, duration: 2)
        
        if onMonitor {
            arView.prepare([screenNode], completionHandler: { success in
                if success {
                    monitor?.addChildNode(screenNode)
                    screenNode.position = SCNVector3(-0.052, 0.352, 0.152)
                }
            })
        } else {
            arView.prepare([screenNode], completionHandler: { success in
                if success {
                    self.arView.scene.rootNode.addChildNode(screenNode)
                    let position = SCNVector3(x: 0, y: 0, z: -1.5)
                    self.updatePositionAndOrientationOf(screenNode, withPosition: position, relativeTo: self.arView.pointOfView!)
                    screenNode.scale = SCNVector3(0, 0, 0)
                    screenNode.runAction(animation)
                    
                    if self.arView.scene.rootNode.childNode(withName: "screen", recursively: true) != nil {
                        self.madeScreenBig = true
                    } else {
                        self.instruction = "Error, trying again."
                        self.addScreen(onMonitor: false)
                    }
                } else {
                    self.instruction = "Error, trying again."
                    self.addScreen(onMonitor: false)
                }
            })
        }
    }
    
    var monitorHitTestResult: ARHitTestResult!
    
    func addMonitor(tappedPosition: CGPoint)  {
        let hitTest = arView.hitTest(tappedPosition, types: [.existingPlaneUsingExtent])
        
        if hitTest.isEmpty {
            instruction = "No surface detected. Please try again."
        } else if let result = hitTest.first {
            let anchor = ARAnchor(name: "MonitorAnchor", transform: result.worldTransform)
            monitorHitTestResult = result
            arView.session.add(anchor: anchor)
        }
        
    }
    
    func addText(_ text: String) {
        
        let monitor = arView.scene.rootNode.childNode(withName: "monitor", recursively: true)
        
        let text = SCNText(string: text, extrusionDepth: 0.2)
        let textNode = SCNNode(geometry: text)
        
        let material = SCNMaterial()
        material.diffuse.contents = UIColor.white
        text.materials = [material]
        text.font = UIFont.systemFont(ofSize: 10, weight: .medium)
        text.isWrapped = true
        text.containerFrame = CGRect(origin: .zero, size: CGSize(width: 200, height: 100))
        
        textNode.position = SCNVector3(-0.3, 0.3, 0)
        textNode.scale = SCNVector3(0.005, 0.005, 0.005)
        textNode.name = "text1"
        
        arView.prepare([textNode], completionHandler: { success in
            monitor?.addChildNode(textNode)
            self.text1 = true
        })
        
        
        print("sgwre")
    }
    
    func updateText(_ text: String) {
        arView.scene.rootNode.childNode(withName: "monitor", recursively: true)?.childNode(withName: "text1", recursively: true)?.removeFromParentNode()
        addText(text)
        text2 = true
    }
    
    func makeScreenBig() {
        let monitor = arView.scene.rootNode.childNode(withName: "monitor", recursively: true)
        let fadeOut = SCNAction.fadeOut(duration: 2)
        monitor?.runAction(fadeOut)
        
        addScreen(onMonitor: false)
    }
    
    func updatePlanet() {
        switch planetPage {
        case 0:
            if currentPlanet != 0 {
                currentPlanet = 0
                addPlanet(named: "earth3d")
            }
        case 1:
            if currentPlanet != 1 {
                currentPlanet = 1
                addPlanet(named: "mercury3d")
            }
        case 2:
            if currentPlanet != 2 {
                currentPlanet = 2
                addPlanet(named: "venus3d")
            }
        case 3:
            if currentPlanet != 3 {
                currentPlanet = 3
                addPlanet(named: "mars3d")
            }
        case 4:
            if currentPlanet != 4 {
                currentPlanet = 4
                addPlanet(named: "jupiter3d")
            }
        case 5:
            if currentPlanet != 5 {
                currentPlanet = 5
                addPlanet(named: "uranus3d")
            }
        case 6:
            if currentPlanet != 6 {
                currentPlanet = 6
                addPlanet(named: "neptune3d")
            }
        case 7:
            if currentPlanet != 7 {
                currentPlanet = 7
                addPlanet(named: "saturn3d")
            }
        default:
            removePlanet()
        }
    }
    
    func addPlanet(named name: String) {
        let screen = arView.scene.rootNode.childNode(withName: "screen", recursively: true)!
        if screen.childNode(withName: "planet", recursively: true) != nil {
            screen.childNode(withName: "planet", recursively: true)!.removeFromParentNode()
        }
        guard let objectsScene = SCNScene(named: "objects.scn"), let planetNode = objectsScene.rootNode.childNode(withName: name, recursively: true) else { return }
        planetNode.name = "planet"
        planetNode.position = SCNVector3(0, 0.7, 0)
        
        arView.prepare([planetNode], completionHandler: { success in
            screen.addChildNode(planetNode)
            let spin = SCNAction.repeatForever(SCNAction.rotate(by: 1, around: SCNVector3(0, 1, 0), duration: 2))
            planetNode.runAction(spin)
            planetNode.scale = SCNVector3(0.2, 0.2, 0.2)
        })
    }
    
    func removePlanet() {
        arView.scene.rootNode.childNode(withName: "screen", recursively: true)?.childNode(withName: "planet", recursively: true)?.removeFromParentNode()
    }
    
    public func renderer(_ renderer: SCNSceneRenderer, didAdd node: SCNNode, for anchor: ARAnchor) {
        if anchor.name == "MonitorAnchor" {
            guard let objectsScene = SCNScene(named: "objects.scn"), let monitorNode = objectsScene.rootNode.childNode(withName: "monitor", recursively: true) else { return }
            let rotate = simd_float4x4(SCNMatrix4MakeRotation(arView.session.currentFrame!.camera.eulerAngles.y, 0, 1, 0))
            let rotateTransform = simd_mul(monitorHitTestResult.worldTransform, rotate)
            node.transform = SCNMatrix4(rotateTransform)
            arView.prepare([node, monitorNode], completionHandler: { success in
                node.addChildNode(monitorNode)
                self.addScreen()
                DispatchQueue.main.async {
                    self.addedMonitor = true
                    self.featurePoints(show: false)
                    self.instruction = "Tap to continue."
                }
            })
        }
    }
    
    // Code snippet from Pablo on StackOverflow - https://stackoverflow.com/a/50657180/11678562
    func updatePositionAndOrientationOf(_ node: SCNNode, withPosition position: SCNVector3, relativeTo referenceNode: SCNNode) {
        let referenceNodeTransform = matrix_float4x4(referenceNode.transform)
        
        // Setup a translation matrix with the desired position
        var translationMatrix = matrix_identity_float4x4
        translationMatrix.columns.3.x = position.x
        translationMatrix.columns.3.y = position.y
        translationMatrix.columns.3.z = position.z
        
        // Combine the configured translation matrix with the referenceNode's transform to get the desired position AND orientation
        let updatedTransform = matrix_multiply(referenceNodeTransform, translationMatrix)
        node.transform = SCNMatrix4(updatedTransform)
    }
    
    // MARK:- * Vision processing.
    
    @Published var enableMl = false
    @Published var gesturesEnabled = true {
        didSet {
            handleTap(position: CGPoint(x: 0, y: 0))
            if gesturesEnabled {
                enableMl = true
            } else {
                enableMl = false
            }
        }
    }
    
    var fingers: [Finger] = []
    @Published var outputMask: CGImage?
    @Published var topPointOfAllFingers = IntPoint(x: 0, y: 0)
    
    @Published var planetPageOffset = 0
    @Published var planetPage = 0
    var currentPlanet = -1
    
    private var currentBuffer: CVPixelBuffer?
    private let visionQueue = DispatchQueue(label: "com.priva28.fingertipdetection.vision")
    private let ciContext = CIContext()
    
    private lazy var visionRequest: VNCoreMLRequest = {
        do {
            let model = try VNCoreMLModel(for: FingertipModel().model)
            let request = VNCoreMLRequest(model: model)
            
            request.imageCropAndScaleOption = .centerCrop
            
            return request
        } catch {
            fatalError("Couldnt find the requested CoreML model.")
        }
    }()
    
    var touching = false
    var touchingW3 = false
    var startPointOfTouch = IntPoint(x: 0, y: 0)
    var previousTranslation = 0
    
    var startDistanceOfFingers: Double = 0
    var previousDistance: Double = 0
    
    var addedMonitor = false
    var text1 = false
    var text2 = false
    var madeScreenBig = false
    var showed5Fingers = false
    var hasSwiped = false
    var showed3Fingers = false
    
    func handleTap(position: CGPoint) {
        if !addedMonitor {
            addMonitor(tappedPosition: position)
        }
        if addedMonitor && !text1 {
            addText("Today, we rely on devices such as TV's, Monitors and Phones to see things.")
        }
        if addedMonitor && text1 && !text2 {
            updateText("AR is different.")
        }
        if addedMonitor && text1 && text2 && !madeScreenBig {
            makeScreenBig()
        }
        if addedMonitor && text1 && text2 && madeScreenBig && !showed5Fingers {
            if gesturesEnabled {
                instruction = "Place five fingers in view of the camera and move your device to move your AR screen."
                showHandGesture1Vid = true
                enableMl = true
            } else {
                showHandGesture1Vid = false
                print("here")
                instruction = "Move your device, then tap and hold to move your AR screen."
            }
        }
        if addedMonitor && text1 && text2 && madeScreenBig && showed5Fingers && !hasSwiped {
            if gesturesEnabled {
                instruction = "Place a finger in view of the camera and swipe between pages."
                showHandGesture2Vid = true
                enableMl = true
            } else {
                showHandGesture2Vid = false
                instruction = "Use arrows on the side to move between pages."
            }
        }
        if addedMonitor && text1 && text2 && madeScreenBig && showed5Fingers && hasSwiped && !showed3Fingers {
            if gesturesEnabled {
                instruction = "Place three fingers and press to show/hide a 3D version of the current page."
                showHandGesture3Vid = true
                enableMl = true
            } else {
                showHandGesture3Vid = false
                instruction = "Press the i button to show/hide a 3D version of the current page."
            }
        }
        if addedMonitor && text1 && text2 && madeScreenBig && showed5Fingers && hasSwiped && showed3Fingers {
            instruction = "Now you can explore the planets yourself!"
            enableMl = true
            PlaygroundPage.current.assessmentStatus = .pass(message: "When your done, continue to the [**next page**](@next)")
        }
    }
    
    public func session(_ session: ARSession, didUpdate frame: ARFrame) {
        // This is where we process the frame from the AR view. This function is called 30 times per second and lets us grab the current frame.
        
        if enableMl {
            // This is going to make sure that we are not currently processing an image. We do this by making sure that the pixel buffer (grabbed frame) is not filled as we empty it when we are done processing.
            guard currentBuffer == nil else { return }
            
            // If we pass the checks above, lets set the current buffer to the new, updated pixel buffer (grabbed frame)
            currentBuffer = frame.capturedImage
            makeMask()
            
            if fingers.count == 1 && !showHandGesture1Vid {
                previousDistance = 0
                startDistanceOfFingers = 0
                if !touching {
                    // Then we are "touching"
                    touching = true
                    startPointOfTouch = topPointOfAllFingers
                    
                } else if touching {
                    let translation = topPointOfAllFingers.x - startPointOfTouch.x
                    if abs(previousTranslation - translation) > 3 {
                        planetPageOffset += translation
                        if planetPageOffset > 350 {
                            planetPage = max(planetPage - 1, 0)
                            planetPageOffset = 0
                            previousTranslation = translation
                            startPointOfTouch = topPointOfAllFingers
                            hasSwiped = true
                            if currentPlanet != -1 {
                                updatePlanet()
                            }
                        } else if planetPageOffset < -450 {
                            planetPage = min(planetPage + 1, 7)
                            planetPageOffset = 0
                            previousTranslation = translation
                            startPointOfTouch = topPointOfAllFingers
                            hasSwiped = true
                            if currentPlanet != -1 {
                                updatePlanet()
                            }
                        }
                    }
                    
                }
            } else if fingers.count == 5 {
                planetPageOffset = 0
                previousTranslation = 0
                let screen = arView.scene.rootNode.childNode(withName: "screen", recursively: true)
                SCNTransaction.animationDuration = 0.3
                let position = SCNVector3(x: 0, y: 0, z: -1.5)
                updatePositionAndOrientationOf(screen!, withPosition: position, relativeTo: arView.pointOfView!)
                showed5Fingers = true
            } else if fingers.count == 3 && !showHandGesture1Vid && !showHandGesture2Vid {
                if !touchingW3 {
                    touchingW3 = true
                    if currentPlanet == -1 {
                        updatePlanet()
                        showed3Fingers = true
                        touchingW3 = true
                    } else {
                        currentPlanet = -1
                        removePlanet()
                        touchingW3 = true
                    }
                }
            }
            
            
            if fingers.count == 0 {
                startDistanceOfFingers = 0
                previousTranslation = 0
                planetPageOffset = 0
                touching = false
                touchingW3 = false
                
                if showed5Fingers && showHandGesture1Vid {
                    showHandGesture1Vid = false
                    instruction = "Good job!"
                    enableMl = false
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                        self.instruction = "Tap to continue."
                    }
                }
                
                if hasSwiped && showHandGesture2Vid {
                    showHandGesture2Vid = false
                    instruction = "Good job!"
                    enableMl = false
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                        self.instruction = "Tap to continue."
                    }
                }
                
                if showed3Fingers && showHandGesture3Vid {
                    showHandGesture3Vid = false
                    instruction = "Good job!"
                    enableMl = false
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                        self.instruction = "Tap to continue."
                    }
                }
            }
            
        }
    }
    
    private func makeMask() {
        
        guard let buffer = currentBuffer else { return }
        
        let orientation = UIDevice.current.orientation
        let imageOrientation: CGImagePropertyOrientation
        switch orientation {
        case .portrait:
            imageOrientation = .right
        case .portraitUpsideDown:
            imageOrientation = .left
        case .landscapeLeft:
            imageOrientation = .up
        case .landscapeRight:
            imageOrientation = .down
        default:
            imageOrientation = .right
        }
        
        let requestHandler = VNImageRequestHandler(cvPixelBuffer: buffer, orientation: imageOrientation)
        
        visionQueue.async {
            do {
                
                defer {
                    self.currentBuffer = nil
                }
                
                try requestHandler.perform([self.visionRequest])
                
                guard let mask = self.visionRequest.results?.first as? VNPixelBufferObservation else {
                    fatalError("Unexpected result type from the vision request.")
                }
                
                let result = mask.pixelBuffer
                let fingers = result.countWhiteDots()
                
                let topPoint = findHighestPoint(fingers: fingers)
                
                DispatchQueue.main.async {
                    
                    let ciImage = CIImage(cvImageBuffer: result)
                    let cgImage = self.ciContext.createCGImage(ciImage, from: ciImage.extent)
                    
                    self.outputMask = cgImage
                    self.topPointOfAllFingers = topPoint
                    self.fingers = fingers
                }
                
            } catch {
                print("fail")
            }
        }
        
    }
}
