
import SwiftUI
import SharedCode

struct StatusView: View {
    
    @EnvironmentObject var arController: ARController
    @State var animation = false
    
    var body: some View {
        VStack {
            Circle()
                .frame(width: 50, height: 50)
                .cornerRadius(100)
                .foregroundColor(Color(red: 0/255, green: 138/255, blue: 253/255))
                .shadow(radius: 10)
                .overlay(
                    Image(systemName: arController.gesturesEnabled ? "hand.raised.slash.fill" : "hand.raised.fill")
                        .foregroundColor(.white)
            )
                .onTapGesture {
                    if self.arController.gesturesEnabled {
                        self.arController.gesturesEnabled = false
                    } else {
                        self.arController.gesturesEnabled = true
                    }
            }
            Spacer()
            ZStack {
                VStack {
                    if arController.showTapGestureDemo {
                        LoopingVid(fileName: "tapGestureDemo")
                            .padding()
                            .frame(width: 355.6, height: 200)
                            .transition(.scale)
                            .animation(.default)
                    }
                    if arController.showSpeedSlider && !arController.showTapGestureDemo {
                        Text("\(arController.speed == 1 ? "The planets are now orbiting at real speed." : arController.speed == 3153600 ? "One Earth year is now 10 seconds." : "")")
                        HStack {
                            Text("\(String(arController.speed).components(separatedBy: ".")[0])x")
                            Slider(value: $arController.speed, in: 1...3153600, step: 1)
                        }
                    }
                    HStack {
                        Image(systemName: "arkit")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 30)
                            .padding(.leading)
                            .foregroundColor(.white)
                            .scaleEffect(animation ? 1 : 0.8)
                            .onAppear {
                                withAnimation(Animation.easeInOut(duration: 1.5).repeatForever(autoreverses: true)) {
                                    self.animation.toggle()
                                }
                        }
                        Text("\(arController.instruction)")
                            .foregroundColor(.white)
                            .padding(.trailing)
                    }
                }
                .padding()
                .background(
                    Rectangle()
                        .cornerRadius(50)
                        .foregroundColor(Color(red: 0/255, green: 138/255, blue: 253/255))
                        .shadow(radius: 10)
                )
                    .animation(.default)
            }
        }
    }
}
