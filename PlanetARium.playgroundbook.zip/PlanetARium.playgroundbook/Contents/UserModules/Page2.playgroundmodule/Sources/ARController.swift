
import ARKit
import SwiftUI
import Vision
import SharedCode
import PlaygroundSupport

public final class ARController: NSObject, ObservableObject, ARSCNViewDelegate, ARSessionDelegate {
    public static var shared = ARController()
    
    var arView = ARSCNView(frame: .init(x: 1, y: 1, width: 1, height: 1))
    
    @Published var instruction = "Please find a table or floor, and tap on the surface through your screen to begin."
    @Published var speed: Double = 3153600 {
        didSet {
            updatePlanets = true
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                self.updatePlanets = false
                if !self.changedSpeed {
                    self.changedSpeed = true
                    self.instruction = "Tap to continue."
                }
            }
        }
    }
    var updatePlanets = false
    
    public override init() {
        super.init()
        
        let config = ARWorldTrackingConfiguration()
        config.planeDetection = .horizontal
        
        
        arView.delegate = self
        arView.session.delegate = self
        arView.autoenablesDefaultLighting = true
        arView.automaticallyUpdatesLighting = true
        arView.session.run(config)
        arView.debugOptions = [.showFeaturePoints]
    }
    
    func featurePoints(show: Bool) {
        if show {
            arView.debugOptions = [.showFeaturePoints]
        } else {
            arView.debugOptions = []
        }
    }
    
    func addSun(tappedPosition: CGPoint) {
        
        let hitTest = arView.hitTest(tappedPosition, types: [.existingPlaneUsingExtent])
        
        if hitTest.isEmpty {
            instruction = "No surface detected. Please try again."
        } else if let result = hitTest.first {
            let anchor = ARAnchor(name: "SunAnchor", transform: result.worldTransform)
            arView.session.add(anchor: anchor)
        }
        
    }
    
    func tapPlanet(tappedPosition: CGPoint) {
        let hitTest = arView.hitTest(tappedPosition, options: nil)
        
        if hitTest.isEmpty {
            instruction = "No planet detected. Please try again."
        } else if let result = hitTest.first {
            let planetNode = result.node
            
            let text = SCNText(string: planetNode.name!.capitalizingFirstLetter(), extrusionDepth: 0.2)
            let textNode = SCNNode(geometry: text)
            
            let material = SCNMaterial()
            material.diffuse.contents = UIColor.white
            text.materials = [material]
            text.font = UIFont.systemFont(ofSize: 10, weight: .medium)
            text.isWrapped = true
            text.containerFrame = CGRect(origin: .zero, size: CGSize(width: 200, height: 100))
            
            textNode.position = SCNVector3(0, 0.8, 0)
            
            textNode.scale = SCNVector3(0.035, 0.035, 0.035)
            
            let contraint = SCNBillboardConstraint()
            contraint.freeAxes = [.all]
            textNode.constraints = [contraint]
            
            planetNode.addChildNode(textNode)
            
            tappedPlanet = true
        }
    }
    
    func addPlanet(called planet: String, fromScene scene: SCNScene, toNode node: SCNNode, orbitSpeed: TimeInterval, spinSpeed: TimeInterval, startRotation: CGFloat, distanceFromSun: CGFloat, size: CGFloat) {
        let turningPointGeometry = SCNSphere()
        let turningPointNode = SCNNode(geometry: turningPointGeometry)
        
        turningPointNode.scale = SCNVector3(1, 1, 1)
        node.addChildNode(turningPointNode)
        
        let planetNode = scene.rootNode.childNode(withName: "\(planet)3d", recursively: true)!
        planetNode.name = planet
        planetNode.scale = SCNVector3(size, size, size)
        planetNode.eulerAngles = SCNVector3(0, startRotation, 0)
        planetNode.position = SCNVector3(0, 0, distanceFromSun + 1.25)
        
        turningPointNode.addChildNode(planetNode)
        turningPointNode.position = SCNVector3(0, 0, 0)
        turningPointNode.eulerAngles = SCNVector3(0, startRotation, 0)
        
        let spin = SCNAction.repeatForever(SCNAction.rotate(by: 6.2831853072, around: SCNVector3(0, 1, 0), duration: spinSpeed))
        planetNode.runAction(spin)
        
        let orbit = SCNAction.repeatForever(SCNAction.rotate(by: 6.2831853072, around: SCNVector3(0, 1, 0), duration: orbitSpeed))
        turningPointNode.runAction(orbit)
    }
    
    public func renderer(_ renderer: SCNSceneRenderer, updateAtTime time: TimeInterval) {
        if updatePlanets {
            updatePlanets = false
            guard let anchors = arView.session.currentFrame?.anchors else {return}
            
            for anchor in anchors {
                if anchor.name == "SunAnchor" {
                    guard let sun = arView.node(for: anchor) else { return }
                    
                    for turningPoint in sun.childNodes.first!.childNodes {
                        turningPoint.removeAllActions()
                        if let planet = turningPoint.childNodes.first {
                            planet.removeAllActions()
                            
                            switch planet.name {
                            case "mercury":
                                let orbit = SCNAction.repeatForever(SCNAction.rotate(by: 6.2831853072, around: SCNVector3(0, 1, 0), duration: 7568640/speed))
                                turningPoint.runAction(orbit)
                            case "venus":
                                let orbit = SCNAction.repeatForever(SCNAction.rotate(by: 6.2831853072, around: SCNVector3(0, 1, 0), duration: 19552320/speed))
                                turningPoint.runAction(orbit)
                            case "earth":
                                let orbit = SCNAction.repeatForever(SCNAction.rotate(by: 6.2831853072, around: SCNVector3(0, 1, 0), duration: 31536000/speed))
                                turningPoint.runAction(orbit)
                            case "mars":
                                let orbit = SCNAction.repeatForever(SCNAction.rotate(by: 6.2831853072, around: SCNVector3(0, 1, 0), duration: 59287680/speed))
                                turningPoint.runAction(orbit)
                            case "jupiter":
                                let orbit = SCNAction.repeatForever(SCNAction.rotate(by: 6.2831853072, around: SCNVector3(0, 1, 0), duration: 374332320/speed))
                                turningPoint.runAction(orbit)
                            case "saturn":
                                let orbit = SCNAction.repeatForever(SCNAction.rotate(by: 6.2831853072, around: SCNVector3(0, 1, 0), duration: 950495040/speed))
                                turningPoint.runAction(orbit)
                            case "uranus":
                                let orbit = SCNAction.repeatForever(SCNAction.rotate(by: 6.2831853072, around: SCNVector3(0, 1, 0), duration: 2678352480/speed))
                                turningPoint.runAction(orbit)
                            case "neptune":
                                let orbit = SCNAction.repeatForever(SCNAction.rotate(by: 6.2831853072, around: SCNVector3(0, 1, 0), duration: 5201232480/speed))
                                turningPoint.runAction(orbit)
                            default:
                                print("")
                            }
                            
                            let spin = SCNAction.repeatForever(SCNAction.rotate(by: 6.2831853072, around: SCNVector3(0, 1, 0), duration: 31500000/speed))
                            planet.runAction(spin)
                            
                        }
                    }
                }
            }
        }
    }
    
    public func renderer(_ renderer: SCNSceneRenderer, didAdd node: SCNNode, for anchor: ARAnchor) {
        if anchor.name == "SunAnchor" {
            print("asdfgh")
            
            let objectsScene = SCNScene(named: "objects.scn")!
            let sunNode = objectsScene.rootNode.childNode(withName: "sun3d", recursively: true)!
            sunNode.name = "sun"
            sunNode.scale = SCNVector3(0.2, 0.2, 0.2)
            sunNode.position = SCNVector3(0, 0.5, 0)
            node.addChildNode(sunNode)
            DispatchQueue.main.async {
                self.addedSun = true
                self.featurePoints(show: false)
                self.instruction = "Tap to continue."
            }
            
            addPlanet(called: "mercury", fromScene: objectsScene, toNode: sunNode, orbitSpeed: 7568640/speed, spinSpeed: 31500000/speed, startRotation: 3.29867, distanceFromSun: 0.04, size: 0.1)
            addPlanet(called: "venus", fromScene: objectsScene, toNode: sunNode, orbitSpeed: 19552320/speed, spinSpeed: 31500000/speed, startRotation: -0.959931, distanceFromSun: 0.35, size: 0.12)
            addPlanet(called: "earth", fromScene: objectsScene, toNode: sunNode, orbitSpeed: 31536000/speed, spinSpeed: 31500000/speed, startRotation: -0.645772, distanceFromSun: 0.7, size: 0.2)
            addPlanet(called: "mars", fromScene: objectsScene, toNode: sunNode, orbitSpeed: 59287680/speed, spinSpeed: 31500000/speed, startRotation: 0.191986, distanceFromSun: 1.5, size: 0.22)
            addPlanet(called: "jupiter", fromScene: objectsScene, toNode: sunNode, orbitSpeed: 374332320/speed, spinSpeed: 31500000/speed, startRotation: 0.296706, distanceFromSun: 2.5, size: 0.5)
            addPlanet(called: "saturn", fromScene: objectsScene, toNode: sunNode, orbitSpeed: 950495040/speed, spinSpeed: 31500000/speed, startRotation: 0.453786, distanceFromSun: 3.9, size: 0.4)
            addPlanet(called: "uranus", fromScene: objectsScene, toNode: sunNode, orbitSpeed: 2678352480/speed, spinSpeed: 31500000/speed, startRotation: 2.21657, distanceFromSun: 5.3, size: 0.3)
            addPlanet(called: "neptune", fromScene: objectsScene, toNode: sunNode, orbitSpeed: 5201232480/speed, spinSpeed: 31500000/speed, startRotation: 1.37881, distanceFromSun: 5.9, size: 0.3)
        }
    }
    
    @Published var showTapGestureDemo = false
    
    var addedSun = false
    var tappedPlanet = false
    @Published var showSpeedSlider = false
    var changedSpeed = false
    
    func handleTap(position: CGPoint = CGPoint(x: 0, y: 0)) {
        if !addedSun {
            addSun(tappedPosition: position)
        }
        if addedSun && !showSpeedSlider {
            showSpeedSlider = true
            instruction = "Drag the slider to change the orbit speed of the planets."
        }
        if addedSun && showSpeedSlider && changedSpeed && !tappedPlanet {
            if !gesturesEnabled {
                self.instruction = "Tap on a planet or sun to see its name."
                tapPlanet(tappedPosition: position)
            } else {
                self.showTapGestureDemo = true
                self.enableMl = true
                self.instruction = "Hold out your finger and press on a planet or sun to see its name."
            }
        }
        if addedSun && showSpeedSlider && changedSpeed && tappedPlanet {
            if !gesturesEnabled {
                tapPlanet(tappedPosition: position)
            } else {
                self.showTapGestureDemo = false
                self.enableMl = true
            }
            PlaygroundPage.current.assessmentStatus = .pass(message: "Now you know about the planets in our solar system, take a quiz on the [**next page**](@next)")
        }
    }
    
    // MARK:- * Vision processing.
    
    @Published var enableMl = false
    @Published var gesturesEnabled = true {
        didSet {
            handleTap(position: CGPoint(x: 0, y: 0))
            if gesturesEnabled {
                enableMl = true
            } else {
                enableMl = false
            }
        }
    }
    @Published var topPointOfAllFingers = IntPoint(x: 0, y: 0)
    
    var fingers: [Finger] = []
    
    private var currentBuffer: CVPixelBuffer?
    private let visionQueue = DispatchQueue(label: "com.priva28.fingertipdetection.vision")
    private let ciContext = CIContext()
    
    private lazy var visionRequest: VNCoreMLRequest = {
        do {
            let model = try VNCoreMLModel(for: FingertipModel().model)
            let request = VNCoreMLRequest(model: model)
            
            request.imageCropAndScaleOption = .centerCrop
            
            return request
        } catch {
            fatalError("Couldnt find the requested CoreML model.")
        }
    }()
    
    var touching = false
    
    var hasTapped = false
    
    public func session(_ session: ARSession, didUpdate frame: ARFrame) {
        // This is where we process the frame from the AR view. This function is called 30 times per second and lets us grab the current frame.
        
        if enableMl {
            // This is going to make sure that we are not currently processing an image. We do this by making sure that the pixel buffer (grabbed frame) is not filled as we empty it when we are done processing.
            guard currentBuffer == nil else { return }
            
            // If we pass the checks above, lets set the current buffer to the new, updated pixel buffer (grabbed frame)
            currentBuffer = frame.capturedImage
            makeMask()
            
            if fingers.count == 1 && fingers[0].size.width < 7 && fingers[0].size.height < 7 {
                if !touching {
                    hasTapped = true
                    let x = CGFloat(fingers[0].topPoint.x).convert(fromRange: (0, 112), toRange: (0, UIScreen.main.bounds.width))
                    let y = CGFloat(fingers[0].topPoint.y).convert(fromRange: (0, 112), toRange: (0, UIScreen.main.bounds.height))
                    tapPlanet(tappedPosition: CGPoint(x: x, y: y))
                }
                touching = true
            } else {
                if hasTapped && showTapGestureDemo {
                    showTapGestureDemo = false
                    instruction = "Good job!"
                    enableMl = true
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                        self.instruction = "Now you know about the planets in our solar system, take a quiz on the next page!"
                        PlaygroundPage.current.assessmentStatus = .pass(message: "When your done, continue to the [**next page**](@next)")
                    }
                }
                touching = false
            }
        }
    }
    
    private func makeMask() {
        
        guard let buffer = currentBuffer else { return }
        
        let orientation = UIDevice.current.orientation
        let imageOrientation: CGImagePropertyOrientation
        switch orientation {
        case .portrait:
            imageOrientation = .right
        case .portraitUpsideDown:
            imageOrientation = .left
        case .landscapeLeft:
            imageOrientation = .up
        case .landscapeRight:
            imageOrientation = .down
        default:
            imageOrientation = .right
        }
        
        let requestHandler = VNImageRequestHandler(cvPixelBuffer: buffer, orientation: imageOrientation)
        
        visionQueue.async {
            do {
                
                defer {
                    self.currentBuffer = nil
                }
                
                try requestHandler.perform([self.visionRequest])
                
                guard let mask = self.visionRequest.results?.first as? VNPixelBufferObservation else {
                    fatalError("Unexpected result type from the vision request.")
                }
                
                let result = mask.pixelBuffer
                let fingers = result.countWhiteDots()
                
                let topPoint = findHighestPoint(fingers: fingers)
                
                DispatchQueue.main.async {
                    self.topPointOfAllFingers = topPoint
                    self.fingers = fingers
                }
                
            } catch {
                print("fail")
            }
        }
        
    }
}
