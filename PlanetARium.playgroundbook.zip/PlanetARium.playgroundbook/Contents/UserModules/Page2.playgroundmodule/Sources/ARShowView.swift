
import SwiftUI
import SharedCode

public struct ARShowView: View {
    
    @State var tap = false
    @EnvironmentObject var arController: ARController
    
    public init() {}
    
    public var body: some View {
        ZStack {
            ARContainerView(arView: ARController.shared.arView)
                .edgesIgnoringSafeArea(.all)
                .gesture(
                    DragGesture(minimumDistance: 0, coordinateSpace: .global)
                        .onChanged { value in
                            if !self.tap {
                                self.tap = true
                                self.arController.handleTap(position: value.location)
                            }
                    }
                    .onEnded { _ in
                        self.tap = false
                    }
            )
            StatusView()
        }
    }
}
