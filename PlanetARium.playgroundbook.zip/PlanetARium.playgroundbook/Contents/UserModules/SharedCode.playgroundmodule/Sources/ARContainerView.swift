
import SwiftUI
import ARKit

public struct ARContainerView: UIViewRepresentable {
    
    public var arView: ARSCNView
    
    public init(arView: ARSCNView) {
        self.arView = arView
    }
    
    public func makeUIView(context: Context) -> ARSCNView {
        return arView
    }
    
    public func updateUIView(_ uiView: ARSCNView, context: Context) { }
}
