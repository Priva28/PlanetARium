public struct IntPoint: Hashable {
    public init(x: Int, y: Int) {
        self.x = x
        self.y = y
    }
    public let x: Int
    public let y: Int
}

public struct IntSize {
    public init(width: Int, height: Int) {
        self.width = width
        self.height = height
    }
    public let width: Int
    public let height: Int
}

public struct Finger {
    public init(topPoint: IntPoint, size: IntSize) {
        self.topPoint = topPoint
        self.size = size
    }
    public let topPoint: IntPoint
    public let size: IntSize
}
