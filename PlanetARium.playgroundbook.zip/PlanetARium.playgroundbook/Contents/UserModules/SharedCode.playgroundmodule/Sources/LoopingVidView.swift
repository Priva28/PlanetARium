

import AVKit
import SwiftUI

public final class LoopingVid: UIViewControllerRepresentable {
    
    var fileName: String
    
    public init(fileName: String) {
        self.fileName = fileName
    }
    
    public func makeUIViewController(context: UIViewControllerRepresentableContext<LoopingVid>) ->
        AVPlayerViewController {
            let controller = AVPlayerViewController()
            
            guard let path = Bundle.main.path(forResource: fileName, ofType: "mp4") else {
                debugPrint("welcome.mp4 not found")
                return controller
            }
            
            let asset = AVAsset(url: URL(fileURLWithPath: path))
            let playerItem = AVPlayerItem(asset: asset)
            let player = AVPlayer(playerItem: playerItem)
            player.actionAtItemEnd = .none
            player.isMuted = true
            
            player.play()
            controller.player = player
            controller.showsPlaybackControls = false
            controller.view.backgroundColor = UIColor(red: 0/255, green: 138/255, blue: 253/255, alpha: 1)
            
            NotificationCenter.default.addObserver(forName: .AVPlayerItemDidPlayToEndTime, object: player.currentItem, queue: .main) { _ in
                player.seek(to: CMTime.zero)
                player.play()
            }
            
            return controller
    }
    
    public func updateUIViewController(_ uiViewController: AVPlayerViewController, context: UIViewControllerRepresentableContext<LoopingVid>) {
    }
}
