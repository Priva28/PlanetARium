
import Vision

extension CGFloat {
    public func convert(fromRange: (CGFloat, CGFloat), toRange: (CGFloat, CGFloat)) -> CGFloat {
        var value = self
        value -= fromRange.0
        value /= CGFloat(fromRange.1 - fromRange.0)
        value *= toRange.1 - toRange.0
        value += toRange.0
        return value
    }
}

extension String {
    public func capitalizingFirstLetter() -> String {
        return prefix(1).uppercased() + self.lowercased().dropFirst()
    }
}

public func findHighestPoint(fingers: [Finger]) -> IntPoint {
    var returnVal = IntPoint(x: 0, y: 0)
    
    if fingers.count > 0 {
        var highestPoint = 0
        var highestPointIndex = 0
        
        for index in 0..<fingers.count {
            if fingers[index].topPoint.y > highestPoint {
                highestPoint = fingers[index].topPoint.y
                highestPointIndex = index
            }
        }
        
        returnVal = fingers[highestPointIndex].topPoint
    }
    
    return returnVal
}

public func distance(_ a: IntPoint, _ b: IntPoint) -> Double {
    let xDist = a.x - b.x
    let yDist = a.y - b.y
    return sqrt(Double(xDist * xDist + yDist * yDist))
}

extension CVPixelBuffer {
    public func countWhiteDots() -> [Finger] {
        // Get width and height of buffer
        let width = CVPixelBufferGetWidth(self)
        let height = CVPixelBufferGetHeight(self)
        
        let bytesPerRow = CVPixelBufferGetBytesPerRow(self)
        
        // Lock buffer
        CVPixelBufferLockBaseAddress(self, CVPixelBufferLockFlags(rawValue: 0))
        
        // Unlock buffer upon exiting
        defer {
            CVPixelBufferUnlockBaseAddress(self, CVPixelBufferLockFlags(rawValue: 0))
        }
        
        var alreadyCounted: Set<IntPoint> = [] // We need to keep count of the pixels we have already analysed so we dont check them again.
        var foundDots: [Finger] = []
        
        if let baseAddress = CVPixelBufferGetBaseAddress(self) {
            let buffer = baseAddress.assumingMemoryBound(to: UInt8.self)
            
            // Check from the point (0, 0) going right, down.
            for y in 0 ..< height {
                for x in 0 ..< width {
                    
                    // Record the current pixel that we are analysing from and get it's value.
                    let currentPixel = IntPoint(x: x, y: y)
                    let currentPixelValue = buffer[currentPixel.y * bytesPerRow + currentPixel.x * 4]
                    
                    // If the value is greater than 0, it isn't black, and therefore could be part of a white dot.
                    if currentPixelValue > 0 && !alreadyCounted.contains(currentPixel) {
                        
                        var whitePixelsToRightOnTop = 0
                        
                        // Now we need to know how wide the dot actually is so we can count down from the middle and get a more accurate result.
                        // The range doesn't matter because we will manually break when we stop seeing white pixels.
                        countHorizontalFromFirstWhite: for i in 0...100 {
                            let pixel = IntPoint(x: x + i, y: y)
                            let pixelValue = buffer[pixel.y * bytesPerRow + pixel.x * 4]
                            
                            // If the pixel is white, record it, otherwise stop looking.
                            if pixelValue > 0 {
                                whitePixelsToRightOnTop += 1
                            } else {
                                break countHorizontalFromFirstWhite
                            }
                        }
                        
                        var whitePixelsDown = 0
                        
                        countDownFromMiddle: for i in 0...100 {
                            let pixel = IntPoint(x: (x + whitePixelsToRightOnTop/2) - 1, y: y + i)
                            let pixelValue = buffer[pixel.y * bytesPerRow + pixel.x * 4]
                            
                            if pixelValue > 0 {
                                whitePixelsDown += 1
                            } else {
                                break countDownFromMiddle
                            }
                        }
                        
                        var whitePixelsLeft = 0
                        
                        countLeftFromCenter: for i in 0...100 {
                            let pixel = IntPoint(x: ((x + whitePixelsToRightOnTop/2) - 1) - i, y: y + whitePixelsDown/2)
                            let pixelValue = buffer[pixel.y * bytesPerRow + pixel.x * 4]
                            
                            if pixelValue > 0 {
                                whitePixelsLeft += 1
                            } else {
                                break countLeftFromCenter
                            }
                        }
                        
                        var whitePixelsRight = 0
                        
                        countRightFromCenter: for i in 0...100 {
                            let pixel = IntPoint(x: ((x + whitePixelsToRightOnTop/2) - 1) + i, y: y + whitePixelsDown/2)
                            let pixelValue = buffer[pixel.y * bytesPerRow + pixel.x * 4]
                            
                            if pixelValue > 0 {
                                whitePixelsRight += 1
                            } else {
                                break countRightFromCenter
                            }
                        }
                        
                        // Now that we have the size of the dot we draw a box around it that is one pixel bigger, just to make sure, and add it to the already counted array so that it is ignored in the future.
                        for yCounted in (y-1...y+whitePixelsDown+1) {
                            for xCounted in (x-whitePixelsLeft-1...x+whitePixelsRight+1) {
                                let pixelFound = IntPoint(x: xCounted, y: yCounted)
                                alreadyCounted.insert(pixelFound)
                            }
                        }
                        
                        let whitePixelsHorizontal = whitePixelsLeft + whitePixelsRight
                        
                        // If the dot is greater than or equal to 4x4 pixels, we've found a dot! Yay!!
                        if whitePixelsHorizontal >= 4 && whitePixelsDown >= 4 {
                            foundDots.append(Finger(topPoint: currentPixel, size: IntSize(width: whitePixelsHorizontal, height: whitePixelsDown)))
                        }
                        
                    }
                }
            }
        }
        
        return foundDots
    }
}
