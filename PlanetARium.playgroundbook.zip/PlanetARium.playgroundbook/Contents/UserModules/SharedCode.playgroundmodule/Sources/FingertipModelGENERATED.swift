

//
// FingertipModel.swift
//
// This file was automatically generated and should not be edited.
//

import CoreML


/// Model Prediction Input Type
@available(macOS 10.14, iOS 12.0, tvOS 12.0, watchOS 5.0, *)
class FingertipModelInput : MLFeatureProvider {
    
    /// 0 as color (kCVPixelFormatType_32BGRA) image buffer, 224 pixels wide by 224 pixels high
    var _0: CVPixelBuffer
    
    var featureNames: Set<String> {
        get {
            return ["0"]
        }
    }
    
    func featureValue(for featureName: String) -> MLFeatureValue? {
        if (featureName == "0") {
            return MLFeatureValue(pixelBuffer: _0)
        }
        return nil
    }
    
    init(_0: CVPixelBuffer) {
        self._0 = _0
    }
}

/// Model Prediction Output Type
@available(macOS 10.14, iOS 12.0, tvOS 12.0, watchOS 5.0, *)
class FingertipModelOutput : MLFeatureProvider {
    
    /// Source provided by CoreML
    
    private let provider : MLFeatureProvider
    
    
    /// 595 as color (kCVPixelFormatType_32BGRA) image buffer, 112 pixels wide by 112 pixels high
    lazy var _595: CVPixelBuffer = {
        [unowned self] in return self.provider.featureValue(for: "595")!.imageBufferValue
        }()!
    
    var featureNames: Set<String> {
        return self.provider.featureNames
    }
    
    func featureValue(for featureName: String) -> MLFeatureValue? {
        return self.provider.featureValue(for: featureName)
    }
    
    init(_595: CVPixelBuffer) {
        self.provider = try! MLDictionaryFeatureProvider(dictionary: ["595" : MLFeatureValue(pixelBuffer: _595)])
    }
    
    init(features: MLFeatureProvider) {
        self.provider = features
    }
}


/// Class for model loading and prediction
@available(macOS 10.14, iOS 12.0, tvOS 12.0, watchOS 5.0, *)
public class FingertipModel {
    public var model: MLModel
    
    /// URL of model assuming it was installed in the same bundle as this class
    class var urlOfModelInThisBundle : URL {
        let bundle = Bundle.main
        return bundle.url(forResource: "FingertipModel", withExtension:"mlmodelc")!
    }
    
    /**
     Construct a model with explicit path to mlmodelc file
     - parameters:
     - url: the file url of the model
     - throws: an NSError object that describes the problem
     */
    public init(contentsOf url: URL) throws {
        self.model = try MLModel(contentsOf: url)
    }
    
    /// Construct a model that automatically loads the model from the app's bundle
    public convenience init() {
        try! self.init(contentsOf: type(of:self).urlOfModelInThisBundle)
    }
    
    /**
     Construct a model with configuration
     - parameters:
     - configuration: the desired model configuration
     - throws: an NSError object that describes the problem
     */
    public convenience init(configuration: MLModelConfiguration) throws {
        try self.init(contentsOf: type(of:self).urlOfModelInThisBundle, configuration: configuration)
    }
    
    /**
     Construct a model with explicit path to mlmodelc file and configuration
     - parameters:
     - url: the file url of the model
     - configuration: the desired model configuration
     - throws: an NSError object that describes the problem
     */
    public init(contentsOf url: URL, configuration: MLModelConfiguration) throws {
        self.model = try MLModel(contentsOf: url, configuration: configuration)
    }
    
    /**
     Make a prediction using the structured interface
     - parameters:
     - input: the input to the prediction as FingertipModelInput
     - throws: an NSError object that describes the problem
     - returns: the result of the prediction as FingertipModelOutput
     */
    func prediction(input: FingertipModelInput) throws -> FingertipModelOutput {
        return try self.prediction(input: input, options: MLPredictionOptions())
    }
    
    /**
     Make a prediction using the structured interface
     - parameters:
     - input: the input to the prediction as FingertipModelInput
     - options: prediction options 
     - throws: an NSError object that describes the problem
     - returns: the result of the prediction as FingertipModelOutput
     */
    func prediction(input: FingertipModelInput, options: MLPredictionOptions) throws -> FingertipModelOutput {
        let outFeatures = try model.prediction(from: input, options:options)
        return FingertipModelOutput(features: outFeatures)
    }
    
    /**
     Make a prediction using the convenience interface
     - parameters:
     - _0 as color (kCVPixelFormatType_32BGRA) image buffer, 224 pixels wide by 224 pixels high
     - throws: an NSError object that describes the problem
     - returns: the result of the prediction as FingertipModelOutput
     */
    func prediction(_0: CVPixelBuffer) throws -> FingertipModelOutput {
        let input_ = FingertipModelInput(_0: _0)
        return try self.prediction(input: input_)
    }
    
    /**
     Make a batch prediction using the structured interface
     - parameters:
     - inputs: the inputs to the prediction as [FingertipModelInput]
     - options: prediction options 
     - throws: an NSError object that describes the problem
     - returns: the result of the prediction as [FingertipModelOutput]
     */
    func predictions(inputs: [FingertipModelInput], options: MLPredictionOptions = MLPredictionOptions()) throws -> [FingertipModelOutput] {
        let batchIn = MLArrayBatchProvider(array: inputs)
        let batchOut = try model.predictions(from: batchIn, options: options)
        var results : [FingertipModelOutput] = []
        results.reserveCapacity(inputs.count)
        for i in 0..<batchOut.count {
            let outProvider = batchOut.features(at: i)
            let result =  FingertipModelOutput(features: outProvider)
            results.append(result)
        }
        return results
    }
}
