
import SwiftUI

struct StatusView: View {
    
    @EnvironmentObject var arController: ARController3
    @State var animation = false
    
    var body: some View {
        ZStack {
            if arController.win {
                ConfettiView()
                VStack {
                    Text("You Win!! 🎉")
                        .font(.largeTitle)
                    Text("\(arController.correctQuestions)/\(10) right.")
                        .font(.largeTitle)
                }
            }
            if arController.lose {
                VStack {
                    Text("You Lost. 😢")
                        .font(.largeTitle)
                    Text("\(arController.correctQuestions)/\(10) right.")
                        .font(.largeTitle)
                }
            }
            VStack {
                Circle()
                    .frame(width: 50, height: 50)
                    .cornerRadius(100)
                    .foregroundColor(Color(red: 0/255, green: 138/255, blue: 253/255))
                    .shadow(radius: 10)
                    .overlay(
                        Image(systemName: arController.gesturesEnabled ? "hand.raised.slash.fill" : "hand.raised.fill")
                            .foregroundColor(.white)
                )
                    .onTapGesture {
                        if self.arController.gesturesEnabled {
                            self.arController.gesturesEnabled = false
                        } else {
                            self.arController.gesturesEnabled = true
                        }
                }
                Spacer()
                if arController.askingQuestion {
                    VStack(spacing: 10) {
                        HStack {
                            answerText(index: 0)
                            answerText(index: 1)
                        }
                        HStack {
                            answerText(index: 2)
                            answerText(index: 3)
                        }
                    }
                }
                ZStack {
                    if arController.gesturesEnabled {
                        HStack {
                            CircularProgress()
                                .frame(width: 80, height: 80)
                                .padding()
                            Spacer()
                        }
                    }
                    HStack {
                        Image(systemName: arController.askingQuestion ? "questionmark.circle.fill" : "arkit")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 30)
                            .padding(.leading)
                            .foregroundColor(.white)
                            .scaleEffect(animation ? 1 : 0.8)
                            .onAppear {
                                withAnimation(Animation.easeInOut(duration: 1.5).repeatForever(autoreverses: true)) {
                                    self.animation.toggle()
                                }
                        }
                        Text("\(arController.instruction)")
                            .foregroundColor(.white)
                            .padding(.trailing)
                    }
                    .padding()
                    .background(
                        Rectangle()
                            .cornerRadius(50)
                            .foregroundColor(Color(red: 0/255, green: 138/255, blue: 253/255))
                            .shadow(radius: 10)
                    )
                        .animation(.default)
                }
            }
        }
    }
    
    func answerText(index: Int) -> some View {
        Text("\(index + 1): \(questions[arController.questionIndex].answers[index])")
            .foregroundColor(.white)
            .padding()
            .background(
                Rectangle()
                    .cornerRadius(50)
                    .foregroundColor(Color(red: 0/255, green: 138/255, blue: 253/255))
                    .shadow(radius: 10)
                    .frame(width: 150)
                    .onTapGesture {
                        
                        if !self.arController.gesturesEnabled {
                            self.arController.askingQuestion = false
                            if questions[self.arController.questionIndex].answer == index + 1 {
                                self.arController.instruction = "Correct! \(questions[self.arController.questionIndex].explanation)"
                                self.arController.questionCorrect = true
                                self.arController.correctQuestions += 1
                                
                            } else {
                                self.arController.instruction = "Incorrect! \(questions[self.arController.questionIndex].explanation)"
                                self.arController.questionIncorrect = true
                                self.arController.incorrectQuestions += 1
                            }
                            
                            switch self.arController.questionIndex {
                            case 0:
                                self.arController.showPlanet(named: "mercury3d")
                            case 1:
                                self.arController.showPlanet(named: "jupiter3d")
                            case 2:
                                self.arController.showPlanet(named: "neptune3d")
                            case 3:
                                break
                            case 4:
                                self.arController.showPlanet(named: "earth3d")
                            case 5:
                                self.arController.showPlanet(named: "saturn3d")
                            case 6:
                                break
                            case 7:
                                break
                            case 8:
                                break
                            case 9:
                                break
                            default:
                                break
                            }
                            
                            DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) {
                                self.arController.finishedQuestion()
                            }
                        }
                }
        )
            .animation(.default)
            .frame(width: 150)
    }
}
