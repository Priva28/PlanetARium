
import SwiftUI

struct CircularProgress: View {
    
    @EnvironmentObject var arController: ARController3
    
    var body: some View {
        ZStack {
            Circle()
                .stroke(lineWidth: 10)
                .opacity(0.3)
                .foregroundColor(.blue)
            Circle()
                .trim(from: 0, to: arController.fingerTimer.convert(fromRange: (0, 30), toRange: (0, 1)))
                .stroke(style: StrokeStyle(lineWidth: 10, lineCap: .round))
                .opacity(1)
                .foregroundColor(.blue)
                .rotationEffect(.degrees(-90))
                .animation(.linear)
            if arController.questionCorrect || arController.questionIncorrect {
                Image(systemName: arController.questionCorrect ? "checkmark" : "xmark")
                    .resizable()
                    .frame(width: 40, height: 40)
                    .foregroundColor(arController.questionCorrect ? .green : .red)
            }
        }
    }
}
