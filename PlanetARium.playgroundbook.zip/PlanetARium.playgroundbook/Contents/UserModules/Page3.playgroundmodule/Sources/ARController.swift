
import SwiftUI
import Vision
import ARKit
import SharedCode
import PlaygroundSupport

public final class ARController3: NSObject, ObservableObject, ARSCNViewDelegate, ARSessionDelegate {
    public static var shared = ARController3()
    
    var arView = ARSCNView(frame: .init(x: 1, y: 1, width: 1, height: 1))
    
    @Published var instruction = "Tap to start."
    @Published var askingQuestion = false
    @Published var questionIndex = 0
    @Published var correctQuestions = 0
    @Published var incorrectQuestions = 0
    @Published var questionCorrect = false
    @Published var questionIncorrect = false
    @Published var win = false
    @Published var lose = false
    
    public override init() {
        
        super.init()
        
        let config = ARWorldTrackingConfiguration()
        config.planeDetection = .horizontal
        arView.delegate = self
        arView.session.delegate = self
        arView.autoenablesDefaultLighting = true
        arView.automaticallyUpdatesLighting = true
        arView.session.run(config)
    }
    
    func showPlanet(named name: String) {
        
        arView.scene.rootNode.enumerateChildNodes { (node, stop) in
            node.removeFromParentNode()
        }
        
        guard let objectsScene = SCNScene(named: "objects.scn"), let planetNode = objectsScene.rootNode.childNode(withName: name, recursively: true) else { return }
        planetNode.name = "planet"
        planetNode.position = SCNVector3(0, 0.7, 0)
        
        arView.prepare([planetNode], completionHandler: { success in
            self.arView.scene.rootNode.addChildNode(planetNode)
            print("planet2")
            self.updatePositionAndOrientationOf(planetNode, withPosition: SCNVector3(0, 0, -1.5), relativeTo: self.arView.pointOfView!)
            let spin = SCNAction.repeatForever(SCNAction.rotate(by: 1, around: SCNVector3(0, 1, 0), duration: 2))
            planetNode.runAction(spin)
            planetNode.scale = SCNVector3(0.2, 0.2, 0.2)
        })
    }
    
    func updatePositionAndOrientationOf(_ node: SCNNode, withPosition position: SCNVector3, relativeTo referenceNode: SCNNode) {
        let referenceNodeTransform = matrix_float4x4(referenceNode.transform)
        
        // Setup a translation matrix with the desired position
        var translationMatrix = matrix_identity_float4x4
        translationMatrix.columns.3.x = position.x
        translationMatrix.columns.3.y = position.y
        translationMatrix.columns.3.z = position.z
        
        // Combine the configured translation matrix with the referenceNode's transform to get the desired position AND orientation
        let updatedTransform = matrix_multiply(referenceNodeTransform, translationMatrix)
        node.transform = SCNMatrix4(updatedTransform)
    }
    
    func handleTap() {
        if !askingQuestion && questionIndex <= 9 {
            arView.scene.rootNode.enumerateChildNodes { (node, stop) in
                node.removeFromParentNode()
            }
            askingQuestion = true
            enableMl = true
            instruction = questions[questionIndex].question
            if questionIndex == 3 {
                showPlanet(named: "earth3d")
            } else if questionIndex == 6 {
                showPlanet(named: "mars3d")
            } else if questionIndex == 7 {
                showPlanet(named: "mercury3d")
            } else if questionIndex == 8 {
                showPlanet(named: "earth3d")
            } else if questionIndex == 9 {
                showPlanet(named: "uranus3d")
            }
        }
    }
    
    @Published var enableMl = false
    @Published var gesturesEnabled = true {
        didSet {
            //handleTap(position: CGPoint(x: 0, y: 0))
            if gesturesEnabled {
                enableMl = true
            } else {
                enableMl = false
            }
        }
    }
    
    var fingers: [Finger] = []
    
    private var currentBuffer: CVPixelBuffer?
    private let visionQueue = DispatchQueue(label: "com.priva28.fingertipdetection.vision")
    private let ciContext = CIContext()
    
    private lazy var visionRequest: VNCoreMLRequest = {
        do {
            let model = try VNCoreMLModel(for: FingertipModel().model)
            let request = VNCoreMLRequest(model: model)
            
            request.imageCropAndScaleOption = .centerCrop
            
            return request
        } catch {
            fatalError("Couldnt find the requested CoreML model.")
        }
    }()
    
    @Published var fingerTimer: CGFloat = 0
    var beforeFingers = 0
    
    public func session(_ session: ARSession, didUpdate frame: ARFrame) {
        // This is where we process the frame from the AR view. This function is called 30 times per second and lets us grab the current frame.
        
        if enableMl {
            // This is going to make sure that we are not currently processing an image. We do this by making sure that the pixel buffer (grabbed frame) is not filled as we empty it when we are done processing.
            guard currentBuffer == nil else { return }
            
            // If we pass the checks above, lets set the current buffer to the new, updated pixel buffer (grabbed frame)
            currentBuffer = frame.capturedImage
            makeMask()
            
            switch questionIndex {
            case 0:
                if fingers.count == 1 && beforeFingers != 1 {
                    showPlanet(named: "earth3d")
                }
                if fingers.count == 2 && beforeFingers != 2 {
                    showPlanet(named: "venus3d")
                }
                if fingers.count == 3 && beforeFingers != 3 {
                    showPlanet(named: "mercury3d")
                }
                if fingers.count == 4 && beforeFingers != 4 {
                    showPlanet(named: "mars3d")
                }
            case 1:
                if fingers.count == 1 && beforeFingers != 1 {
                    showPlanet(named: "saturn3d")
                }
                if fingers.count == 2 && beforeFingers != 2 {
                    showPlanet(named: "uranus3d")
                }
                if fingers.count == 3 && beforeFingers != 3 {
                    showPlanet(named: "venus3d")
                }
                if fingers.count == 4 && beforeFingers != 4 {
                    showPlanet(named: "jupiter3d")
                }
            case 2:
                if fingers.count == 1 && beforeFingers != 1 {
                    showPlanet(named: "neptune3d")
                }
                if fingers.count == 2 && beforeFingers != 2 {
                    showPlanet(named: "jupiter3d")
                }
                if fingers.count == 3 && beforeFingers != 3 {
                    showPlanet(named: "mars3d")
                }
                if fingers.count == 4 && beforeFingers != 4 {
                    showPlanet(named: "uranus3d")
                }
            case 3:
                break
            case 4:
                if fingers.count == 1 && beforeFingers != 1 {
                    showPlanet(named: "mars3d")
                }
                if fingers.count == 2 && beforeFingers != 2 {
                    showPlanet(named: "venus3d")
                }
                if fingers.count == 3 && beforeFingers != 3 {
                    showPlanet(named: "saturn3d")
                }
                if fingers.count == 4 && beforeFingers != 4 {
                    showPlanet(named: "earth3d")
                }
            case 5:
                if fingers.count == 1 && beforeFingers != 1 {
                    showPlanet(named: "saturn3d")
                }
                if fingers.count == 2 && beforeFingers != 2 {
                    showPlanet(named: "jupiter3d")
                }
                if fingers.count == 3 && beforeFingers != 3 {
                    showPlanet(named: "uranus3d")
                }
                if fingers.count == 4 && beforeFingers != 4 {
                    showPlanet(named: "earth3d")
                }
            case 6:
                break
            case 7:
                break
            case 8:
                break
            case 9:
                break
            default:
                break
            }
            
            
            if fingers.count == 1 && askingQuestion {
                if beforeFingers != 1 {
                    fingerTimer = 0
                }
                beforeFingers = 1
                fingerTimer += 1
                if fingerTimer >= 30 {
                    fingerTimer = 0
                    askingQuestion = false
                    
                    if questions[questionIndex].answer == 1 {
                        instruction = "Correct! \(questions[questionIndex].explanation)"
                        questionCorrect = true
                        correctQuestions += 1
                    } else {
                        instruction = "Incorrect! \(questions[questionIndex].explanation)"
                        questionIncorrect = true
                        incorrectQuestions += 1
                    }
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) {
                        self.finishedQuestion()
                    }
                }
            }
            
            if fingers.count == 2 && askingQuestion {
                if beforeFingers != 2 {
                    fingerTimer = 0
                }
                beforeFingers = 2
                fingerTimer += 1
                if fingerTimer >= 30 {
                    fingerTimer = 0
                    askingQuestion = false
                    
                    if questions[questionIndex].answer == 2 {
                        instruction = "Correct! \(questions[questionIndex].explanation)"
                        questionCorrect = true
                        correctQuestions += 1
                    } else {
                        instruction = "Incorrect! \(questions[questionIndex].explanation)"
                        questionIncorrect = true
                        incorrectQuestions += 1
                    }
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) {
                        self.finishedQuestion()
                    }
                }
            }
            
            if fingers.count == 3 && askingQuestion {
                if beforeFingers != 3 {
                    fingerTimer = 0
                }
                beforeFingers = 3
                fingerTimer += 1
                if fingerTimer >= 30 {
                    fingerTimer = 0
                    askingQuestion = false
                    
                    if questions[questionIndex].answer == 3 {
                        instruction = "Correct! \(questions[questionIndex].explanation)"
                        questionCorrect = true
                        correctQuestions += 1
                    } else {
                        instruction = "Incorrect! \(questions[questionIndex].explanation)"
                        questionIncorrect = true
                        incorrectQuestions += 1
                    }
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) {
                        self.finishedQuestion()
                    }
                }
            }
            
            if fingers.count == 4 && askingQuestion {
                if beforeFingers != 4 {
                    fingerTimer = 0
                }
                beforeFingers = 4
                fingerTimer += 1
                if fingerTimer >= 30 {
                    fingerTimer = 0
                    askingQuestion = false
                    
                    if questions[questionIndex].answer == 4 {
                        instruction = "Correct! \(questions[questionIndex].explanation)"
                        questionCorrect = true
                        correctQuestions += 1
                    } else {
                        instruction = "Incorrect! \(questions[questionIndex].explanation)"
                        questionIncorrect = true
                        incorrectQuestions += 1
                    }
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) {
                        self.finishedQuestion()
                    }
                }
            }
            
            if fingers.count == 0 {
                beforeFingers = 0
                fingerTimer = 0
            }
            
        }
    }
    
    func finishedQuestion() {
        self.questionCorrect = false
        self.questionIncorrect = false
        self.questionIndex += 1
        
        
        if correctQuestions + incorrectQuestions == 10 {
            self.instruction = "Quiz finished."
            
            if correctQuestions > 6 {
                win = true
                PlaygroundPage.current.assessmentStatus = .pass(message: "You won! Go to the next [**next page**](@next)")
            } else {
                PlaygroundPage.current.assessmentStatus = .pass(message: "You completed the quiz but failed. Go to the next page, or go back and try the quiz again.  [**next page**](@next)")
                lose = true
            }
        } else {
            self.instruction = "Tap to see next question."
        }
    }
    
    private func makeMask() {
        
        guard let buffer = currentBuffer else { return }
        
        let orientation = UIDevice.current.orientation
        let imageOrientation: CGImagePropertyOrientation
        switch orientation {
        case .portrait:
            imageOrientation = .right
        case .portraitUpsideDown:
            imageOrientation = .left
        case .landscapeLeft:
            imageOrientation = .up
        case .landscapeRight:
            imageOrientation = .down
        default:
            imageOrientation = .right
        }
        
        let requestHandler = VNImageRequestHandler(cvPixelBuffer: buffer, orientation: imageOrientation)
        
        visionQueue.async {
            do {
                
                defer {
                    self.currentBuffer = nil
                }
                
                try requestHandler.perform([self.visionRequest])
                
                guard let mask = self.visionRequest.results?.first as? VNPixelBufferObservation else {
                    fatalError("Unexpected result type from the vision request.")
                }
                
                let result = mask.pixelBuffer
                let fingers = result.countWhiteDots()
                
                DispatchQueue.main.async {
                    
                    self.fingers = fingers
                }
                
            } catch {
                print("fail")
            }
        }
        
    }
}
