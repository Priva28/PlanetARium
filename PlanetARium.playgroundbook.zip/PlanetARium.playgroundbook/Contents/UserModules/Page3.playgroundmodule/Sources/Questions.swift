
struct Question {
    var question: String
    var answers: [String]
    var answer: Int
    var explanation: String
}

let questions = [
    Question(question: "Which planet is closest to the Sun?", answers: ["Earth", "Venus", "Mercury", "Mars"], answer: 3, explanation: "Mercury is the closest planet to the sun"),
    Question(question: "What is the biggest planet in our solar system?", answers: ["Saturn", "Uranus", "Venus", "Jupiter"], answer: 4, explanation: "Jupiter has the largest mass and radius of a planet in our solar system."),
    Question(question: "Which planet is furthest from the sun and has the longest year?", answers: ["Neptune", "Jupiter", "Mars", "Uranus"], answer: 1, explanation: "Neptune is the 8th planet from the sun and has a year that is about 60,190 earth days."),
    Question(question: "Earth's mass is about 5.91 what kg?", answers: ["octillion", "million", "septillion", "sextillion"], answer: 3, explanation: "Earth's mass is about 5.91 septillion kg."),
    Question(question: "Which planet is 3rd from the Sun?", answers: ["Mars", "Venus", "Saturn", "Earth"], answer: 4, explanation: "Earth is the 3rd planet from the sun."),
    Question(question: "Which planet has the most recorded moons?", answers: ["Saturn", "Jupiter", "Uranus", "Earth"], answer: 1, explanation: "Saturn recently overtook Jupiter with the most moons. Saturn has about 82 moons."),
    Question(question: "How many moons does Mars have?", answers: ["0", "1", "2", "3"], answer: 3, explanation: "Mars has 2 moons called Phobos and Deimos."),
    Question(question: "How many Earth days in a Mercury year?", answers: ["88", "101", "365", "223"], answer: 1, explanation: "1 year on Venus is 88 Earth days."),
    Question(question: "What is the radius of Earth?", answers: ["1000 km", "6371 km", "75012 km", "8231 km"], answer: 2, explanation: "Earth's radius is 6371 km."),
    Question(question: "Uranus is how many septillion kg?", answers: ["102.4", "9.5", "71.1", "86.1"], answer: 4, explanation: "Uranus' mass is 86.1 septillion kg.")
]
