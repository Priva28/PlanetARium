
import SwiftUI
import SharedCode

public struct MainView: View {
    
    @EnvironmentObject var arController: ARController3
    
    public init() {}
    
    public var body: some View {
        ZStack {
            ARContainerView(arView: ARController3.shared.arView).onTapGesture {
                self.arController.handleTap()
            }.edgesIgnoringSafeArea(.all)
            StatusView()
        }
    }
}
