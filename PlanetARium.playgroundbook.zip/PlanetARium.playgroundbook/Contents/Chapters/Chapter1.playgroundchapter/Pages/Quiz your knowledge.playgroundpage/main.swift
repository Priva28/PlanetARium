//#-hidden-code
import PlaygroundSupport
import Page3

PlaygroundPage.current.setLiveView(MainView().environmentObject(ARController3.shared))
PlaygroundPage.current.wantsFullScreenLiveView = true
//#-end-hidden-code

//: # Quiz yourself!
//: Now that you've learnt about the solar system, quiz yourself.
//: If you are using the hand gesture control, just put out your hand and show the right amount of fingers to select the answer.

/*:
 - Note:
While this playground works in any orientation, using in portrait will feel more natural because of camera position and is therefore preferred.
*/

/*:
 - Note:
If you are not able to use hand gesture control for any reason, tap the blue hand button at the top to toggle it on and off and use screen taps instead.
*/
