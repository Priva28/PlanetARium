//#-hidden-code
import PlaygroundSupport

PlaygroundPage.current.setLiveView(ContentView().environmentObject(ARController1.shared))
PlaygroundPage.current.wantsFullScreenLiveView = true
//#-end-hidden-code

//: # Infinite Screens!
//: The screens we use today are great, but they are a fixed size and we need to have many of them, or even go to a place such as a theatre, to get the whole big screen experience.
//: Imagine, a high quality screen that is always on you, AND it can be as big as you want.
//: Let's take a glimpse at this technology now through our devices to learn about the solar system.

/*:
 - Note:
While this playground works in any orientation, using in portrait will feel more natural because of camera position and is therefore preferred.
*/

/*:
 - Note:
If you are not able to use hand gesture control for any reason, tap the blue hand button at the top to toggle it on and off and use screen taps instead.
*/
