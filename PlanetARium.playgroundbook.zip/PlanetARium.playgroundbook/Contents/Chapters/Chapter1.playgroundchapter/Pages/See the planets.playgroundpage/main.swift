//#-hidden-code
import PlaygroundSupport
import Page2

PlaygroundPage.current.setLiveView(ARShowView().environmentObject(ARController.shared))
PlaygroundPage.current.wantsFullScreenLiveView = true
//#-end-hidden-code

//: # Solar System
//: It's great seeing AR screens and how they can be used to learn and interact with, but not everything is 2D.

//: Let's see a 3D, interactive AR demo.

/*:
 - Note:
While this playground works in any orientation, using in portrait will feel more natural because of camera position and is therefore preferred.
*/

/*:
 - Note:
If you are not able to use hand gesture control for any reason, tap the blue hand button at the top to toggle it on and off and use screen taps instead.
*/

