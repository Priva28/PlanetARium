//#-hidden-code
import PlaygroundSupport
import Page4

PlaygroundPage.current.setLiveView(DebugView().environmentObject(PublicObject()))
PlaygroundPage.current.wantsFullScreenLiveView = true
//#-end-hidden-code

//: # How it works.
//: I wanted to include a last page so that you can see how the gesture control works. While it is not perfect right now and might not seem great to use on a device such as your iPad, I have created it to show a possibility of how we would interact with AR objects in the future, wether that is through some smart glasses or something else, we will need a way to interact with the virtual world that feels natural. Thats why I tried to implement hand tracking the best that I could.

//: This view is a basic debug view that shows 4 main things.

/*:
 - 1. Output mask of the ML model in the top left corner.
 - 2. Number of detected fingers from output mask.
 - 3. The position of the topmost finger on the output mask.
 - 4. Size of the first detected finger.
*/

/*:
 - Note:
While this playground works in any orientation, using in portrait will feel more natural because of camera position and is therefore preferred.
*/

/*:
 - Note:
If you are not able to use hand gesture control for any reason, tap the blue hand button at the top to toggle it on and off and use screen taps instead.
*/
