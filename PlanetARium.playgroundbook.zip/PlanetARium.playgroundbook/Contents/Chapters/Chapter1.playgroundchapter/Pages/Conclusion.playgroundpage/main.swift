//: # Conclusion

/*:
 I really hope you enjoyed using my Playground, and I hope you learnt something. Thank you for taking the time to use it and hopefully you see something good out of it.
 */
//:  Christian
