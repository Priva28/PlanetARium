//: # PlanetARium

/*:
 * Callout(Welcome to my Swift Playground):
 Hello, my name is Christian. I am a 16 year old from Australia, that loves using code to create amazing things. I love to use Apple's frameworks to create apps and experiment with. I have been using Swift for many years and I decided to start making my own full-featured app this year (which is only half completed right now). I am someone that is very intrigued by AR and the effect that it will have on our future and that's why I decided to create this playground to show the possibilities of AR with `ARKit`. I decided to encorparate Machine Learning as this is another thing I feel strongly about and belive will really change how we do things. It might be as simple as detecting a hand gesture now, but with the way neural networks work, in the future we may even be able to do crazy things with ML such as curing diseases. I used Apple's latest UI framework,  `SwiftUI`, to tie this whole experience together as it makes it very easy to create beautiful interfaces. I hope you enjoy testing my playground and hopefully everything works as expected!
*/

/*:
 - Note:
This Playground uses the camera, and this therefore intented to be run on an iPad.
*/

/*:
 - Note:
While this playground works in any orientation, using in portrait will feel more natural because of camera position and is therefore preferred.
*/

/*:
 - Note:
If you are not able to use hand gesture control for any reason, tap the blue hand button at the top to toggle it on and off and use screen taps instead.
*/
